class CfgPatches
{
	class TanoaServer
	{
		units[]={"C_man_1"};
		weapons[]={};
		requiredAddons[]={"extDB3"};
		fileName="Tanoa-Server.pbo";
		author[]={"Lyeed"};
	};
};

/* Functions */
#include "configs\functions.h"

/* Configs */
#include "configs\Config_Server.hpp"
