class CfgMods
{
	author="76561198007960495";
	timepacked="";
};
