class ADENIS_ATM
{
	class Land_Atm_01_F
	{
		money_stock=2000000;
		money_faction=0;
		company_money_transfert=1;
		company_money_get=0;
		withdraw_max=50000;
		withdraw_min=50;
		withdraw_tax=3;
		deposit_max=10000;
		deposit_min=50;
		launder_transfer=0;
		company=0;
		save=1;
		tablet=1;
		class marker
		{
		 	ShapeLocal="ICON";
			TypeLocal="Maels_dab";
			ColorLocal="ColorWhite";
			SizeLocal[]={0.55, 0.55};
		};
	};

	class Land_Atm_02_F
	{
		money_stock=900000000;
		money_faction=1;
		company_money_transfert=0;
		company_money_get=1;
		withdraw_max=1000000;
		withdraw_min=10;
		withdraw_tax=0;
		deposit_max=1000000;
		deposit_min=10;
		launder_transfer=1;
		company=1;
		save=0;
		tablet=1;
		class marker
		{
		 	ShapeLocal="ICON";
			TypeLocal="Maels_dab";
			ColorLocal="ColorRed";
			SizeLocal[]={0.55, 0.55};
		};
	};
};
