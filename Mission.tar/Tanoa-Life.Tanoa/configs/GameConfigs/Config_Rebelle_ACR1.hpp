class Default_Item_Accred1
{
	buy_license_CIV[]={"rebelle_1"};
	buy_condition_CIV=1;
	buy_price=9999999;
};
