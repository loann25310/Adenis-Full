class ADENIS_WHITELIST
{
	admin_slots[] =
	{
		"CIV_131",
		"CIV_132"
	};

	donator_slots[] =
	{
		"CIV_111",
		"CIV_112",
		"CIV_113",
		"CIV_114",
		"CIV_115",
		"CIV_116",
		"CIV_117",
		"CIV_118",
		"CIV_119",
		"CIV_120",
		"CIV_121",
		"CIV_122",
		"CIV_123",
		"CIV_124",
		"CIV_125"
	};
};