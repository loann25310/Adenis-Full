class Default_Item_Accred2
{
	buy_license_CIV[]={"rebelle_1"};
	buy_condition_CIV=2;
	buy_price=9999999;
};
