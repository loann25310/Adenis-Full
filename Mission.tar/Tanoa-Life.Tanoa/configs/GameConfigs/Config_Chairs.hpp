class ADENIS_CHAIRS
{
	class Land_Chair_EP1
	{
		height=0;
		anim="Crew";
		dir=180;
	};
	class Land_CampingChair_V1_F: Land_Chair_EP1 {};
	class Diablo_Siege_1: Land_Chair_EP1 {};
	class Diablo_Siege_2: Land_Chair_EP1 {};
	class Diablo_Siege_3: Land_Chair_EP1 {};
	class Land_CampingChair_V2_F: Land_Chair_EP1 {};
	class Land_OfficeChair_01_F: Land_Chair_EP1 {};
	class Land_ChairWood_F: Land_Chair_EP1 {};
	class Land_RattanChair_01_F: Land_Chair_EP1 {};
	class WoodChair: Land_Chair_EP1 {};
	class Bleacher_EP1: Land_Chair_EP1 {};
	class Land_Bench_F: Land_Chair_EP1 {};
	class Land_Bench_04_F: Land_Chair_EP1 {};
	class Land_ChairPlastic_F: Land_Chair_EP1 {};
	class FoldChair: Land_Chair_EP1 {};
	class Park_bench1: Land_Chair_EP1 {};
	class Park_bench2: Land_Chair_EP1 {};
	class Park_bench2_noRoad: Land_Chair_EP1 {};
	class Land_Bench_EP1: Land_Chair_EP1 {};
	class Alysia_Medical_Lit_01_F
	{
		height=0;
		anim="ainjppnemstpsnonwrfldnon";
		dir=0;
	};
	class HealTable_F
	{
		height=0;
		anim="ainjppnemstpsnonwrfldnon";
		dir=0;
	};
	class Alysia_Medical_Brancard_01_F
	{
		height=0;
		anim="ainjppnemstpsnonwrfldnon";
		dir=0;
	};
	class HospitalTable_F
	{
		height=0;
		anim="ainjppnemstpsnonwrfldnon";
		dir=0;
	};
};
