class ADENIS_TAXES
{
	class gServer_tax_companies_employee_multiplier
	{
		name="Taxe salariale";
	};
	class gServer_tax_companies_building_multiplier
	{
		name="Taxe foncière";
	};
	class gServer_tax_salary_multiplier
	{
		name="Dette envers le PTI";
	};
	class gServer_tax_house_multiplier
	{
		name="Taxe d'habitation";
	};
};
