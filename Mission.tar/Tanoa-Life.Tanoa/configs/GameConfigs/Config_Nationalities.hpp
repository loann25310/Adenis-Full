class ADENIS_NATIONALITIES
{
	class Tanocien
	{
		name="Tanocien";
		flag="\Alysia_Client_Texture\Data\faction\CIV_logo.paa";
	};
	class Afghanistan
	{
		name="Afghanistan";
		flag="\Alysia_Client_Texture\Data\countries\Afghanistan.paa";
	};
	class SouthAfrica
	{
		name="Afrique du Sud";
		flag="\Alysia_Client_Texture\Data\countries\SouthAfrica.paa";
	};
	class Albania
	{
		name="Albanie";
		flag="\Alysia_Client_Texture\Data\countries\Albania.paa";
	};
	class Algeria
	{
		name="Algérie";
		flag="\Alysia_Client_Texture\Data\countries\Algeria.paa";
	};
	class Germany
	{
		name="Allemagne";
		flag="\Alysia_Client_Texture\Data\countries\Germany.paa";
	};
	class Andorra
	{
		name="Andorre";
		flag="\Alysia_Client_Texture\Data\countries\Andorra.paa";
	};
	class Angola
	{
		name="Angola";
		flag="\Alysia_Client_Texture\Data\countries\Angola.paa";
	};
	class SAudiArabia
	{
		name="Arabie saoudite";
		flag="\Alysia_Client_Texture\Data\countries\SAudiArabia.paa";
	};
	class Argentina
	{
		name="Argentine";
		flag="\Alysia_Client_Texture\Data\countries\Argentina.paa";
	};
	class Armenia
	{
		name="Arménie";
		flag="\Alysia_Client_Texture\Data\countries\Armenia.paa";
	};
	class Australia
	{
		name="Australie";
		flag="\Alysia_Client_Texture\Data\countries\Australia.paa";
	};
	class Azerbajan
	{
		name="Azerbaïdjan";
		flag="\Alysia_Client_Texture\Data\countries\Azerbaijan.paa";
	};
	class Bahamas
	{
		name="Bahamas";
		flag="\Alysia_Client_Texture\Data\countries\Bahamas.paa";
	};
	class Bahrain
	{
		name="Bahreïn";
		flag="\Alysia_Client_Texture\Data\countries\Bahrain.paa";
	};
	class Bangladesh
	{
		name="Bangladesh";
		flag="\Alysia_Client_Texture\Data\countries\Bangladesh.paa";
	};
	class Barbados
	{
		name="Barbade";
		flag="\Alysia_Client_Texture\Data\countries\Barbados.paa";
	};
	class Belgium
	{
		name="Belgique";
		flag="\Alysia_Client_Texture\Data\countries\Belgium.paa";
	};
	class Belize
	{
		name="Belize";
		flag="\Alysia_Client_Texture\Data\countries\Belize.paa";
	};
	class Benin
	{
		name="Bénin";
		flag="\Alysia_Client_Texture\Data\countries\Benin.paa";
	};
	class Belarus
	{
		name="Biélorussie";
		flag="\Alysia_Client_Texture\Data\countries\Belarus.paa";
	};
	class Bolivia
	{
		name="Bolivie";
		flag="\Alysia_Client_Texture\Data\countries\Bolivia.paa";
	};
	class BosniaHerzegovina
	{
		name="Bosnie-Herzégovine";
		flag="\Alysia_Client_Texture\Data\countries\BosniaHerzegovina.paa";
	};
	class Botswana
	{
		name="Botswana";
		flag="\Alysia_Client_Texture\Data\countries\Botswana.paa";
	};
	class Brazil
	{
		name="Brésil";
		flag="\Alysia_Client_Texture\Data\countries\Brazil.paa";
	};
	class Brunei
	{
		name="Brunei";
		flag="\Alysia_Client_Texture\Data\countries\Brunei.paa";
	};
	class Bulgaria
	{
		name="Bulgarie";
		flag="\Alysia_Client_Texture\Data\countries\Bulgaria.paa";
	};
	class images
	{
		name="Burkina Faso";
		flag="\Alysia_Client_Texture\Data\countries\BurkinaFaso";
	};
	class Burundi
	{
		name="Burundi";
		flag="\Alysia_Client_Texture\Data\countries\Burundi.paa";
	};
	class Cambodia
	{
		name="Cambodge";
		flag="\Alysia_Client_Texture\Data\countries\Cambodia.paa";
	};
	class Cameroon
	{
		name="Cameroun";
		flag="\Alysia_Client_Texture\Data\countries\Cameroon.paa";
	};
	class Canada
	{
		name="Canada";
		flag="\Alysia_Client_Texture\Data\countries\Canada.paa";
	};
	class CapeVerde
	{
		name="Cap-Vert" ;
		flag="\Alysia_Client_Texture\Data\countries\CapeVerde.paa";
	};
	class Chile
	{
		name="Chili";
		flag="\Alysia_Client_Texture\Data\countries\Chile.paa";
	};
	class China
	{
		name="Chine";
		flag="\Alysia_Client_Texture\Data\countries\China.paa";
	};
	class CyprusRepublic
	{
		name="Chypre";
		flag="\Alysia_Client_Texture\Data\countries\CyprusRepublic.paa";
	};
	class Colombia
	{
		name="Colombie";
		flag="\Alysia_Client_Texture\Data\countries\Colombia.paa";
	};
	class Comoros
	{
		name="Comores";
		flag="\Alysia_Client_Texture\Data\countries\Comoros.paa";
	};
	class DemocraticCongo
	{
		name="Congo";
		flag="\Alysia_Client_Texture\Data\countries\DemocraticCongo.paa";
	};
	class NorthKorea
	{
		name="Corée du Nord";
		flag="\Alysia_Client_Texture\Data\countries\NorthKorea.paa";
	};
	class Southkorea
	{
		name="Corée du Sud";
		flag="\Alysia_Client_Texture\Data\countries\Southkorea.paa";
	};
	class CostaRica
	{
		name="Costa Rica";
		flag="\Alysia_Client_Texture\Data\countries\CostaRica.paa";
	};
	class IvoiryCoast
	{
		name="Côte d'Ivoire";
		flag="\Alysia_Client_Texture\Data\countries\IvoiryCoast.paa";
	};
	class Croatia
	{
		name="Croatie";
		flag="\Alysia_Client_Texture\Data\countries\Croatia.paa";
	};
	class Cuba
	{
		name="Cuba";
		flag="\Alysia_Client_Texture\Data\countries\Cuba.paa";
	};
	class Denmark
	{
		name="Danemark";
		flag="\Alysia_Client_Texture\Data\countries\Denmark.paa";
	};
	class Djibouti
	{
		name="Djibouti";
		flag="\Alysia_Client_Texture\Data\countries\Djibouti.paa";
	};
	class Dominica
	{
		name="Dominique";
		flag="\Alysia_Client_Texture\Data\countries\Dominica.paa";
	};
	class Egypt
	{
		name="Égypte";
		flag="\Alysia_Client_Texture\Data\countries\Egypt.paa";
	};
	class UnitedArabEmirates
	{
		name="Émirats arabes unis";
		flag="\Alysia_Client_Texture\Data\countries\UnitedArabEmirates.paa";
	};
	class Ecuador
	{
		name="Équateur";
		flag="\Alysia_Client_Texture\Data\countries\Ecuador.paa";
	};
	class Eritrea
	{
		name="Érythrée";
		flag="\Alysia_Client_Texture\Data\countries\Eritrea.paa";
	};
	class Spain
	{
		name="Espagne";
		flag="\Alysia_Client_Texture\Data\countries\Spain.paa";
	};
	class Estonia
	{
		name="Estonie";
		flag="\Alysia_Client_Texture\Data\countries\Estonia.paa";
	};
	class UnitedStates
	{
		name="États-Unis";
		flag="\Alysia_Client_Texture\Data\countries\UnitedStates.paa";
	};
	class Ethiopia
	{
		name="Éthiopie";
		flag="\Alysia_Client_Texture\Data\countries\Ethiopia.paa";
	};
	class Finland
	{
		name="Finlande";
		flag="\Alysia_Client_Texture\Data\countries\Finland.paa";
	};
	class France
	{
		name="France";
		flag="\Alysia_Client_Texture\Data\countries\France.paa";
	};
	class Gabon
	{
		name="Gabon";
		flag="\Alysia_Client_Texture\Data\countries\Gabon.paa";
	};
	class Gambia
	{
		name="Gambie";
		flag="\Alysia_Client_Texture\Data\countries\Gambia.paa";
	};
	class GeorgiaRepublic
	{
		name="Géorgie";
		flag="\Alysia_Client_Texture\Data\countries\GeorgiaRepublic.paa";
	};
	class Ghana
	{
		name="Ghana";
		flag="\Alysia_Client_Texture\Data\countries\Ghana.paa";
	};
	class Greece
	{
		name="Grèce";
		flag="\Alysia_Client_Texture\Data\countries\Greece.paa";
	};
	class Grenada
	{
		name="Grenade";
		flag="\Alysia_Client_Texture\Data\countries\Grenada.paa";
	};
	class Greenland
	{
		name="Groenland";
		flag="\Alysia_Client_Texture\Data\countries\Greenland.paa";
	};
	class Guatemala
	{
		name="Guatemala";
		flag="\Alysia_Client_Texture\Data\countries\Guatemala.paa";
	};
	class Guinea
	{
		name="Guinée";
		flag="\Alysia_Client_Texture\Data\countries\Guinea.paa";
	};
	class GuineaBissau
	{
		name="Guinée-Bissao";
		flag="\Alysia_Client_Texture\Data\countries\GuineaBissau.paa";
	};
	class Guyana
	{
		name="Guyana";
		flag="\Alysia_Client_Texture\Data\countries\Guyana.paa";
	};
	class Haiti
	{
		name="Haïti";
		flag="\Alysia_Client_Texture\Data\countries\Haiti.paa";
	};
	class Honduras
	{
		name="Honduras";
		flag="\Alysia_Client_Texture\Data\countries\Honduras.paa";
	};
	class Hunfrya
	{
		name="Hongrie";
		flag="\Alysia_Client_Texture\Data\countries\Hunfrya.paa";
	};
	class India
	{
		name="Inde";
		flag="\Alysia_Client_Texture\Data\countries\India.paa";
	};
	class Indonesia
	{
		name="Indonésie";
		flag="\Alysia_Client_Texture\Data\countries\Indonesia.paa";
	};
	class Iran
	{
		name="Iran";
		flag="\Alysia_Client_Texture\Data\countries\Iran.paa";
	};
	class Iraq
	{
		name="Iraq";
		flag="\Alysia_Client_Texture\Data\countries\Iraq.paa";
	};
	class Ireland
	{
		name="Irlande";
		flag="\Alysia_Client_Texture\Data\countries\Ireland.paa";
	};
	class Israel
	{
		name="Israël";
		flag="\Alysia_Client_Texture\Data\countries\Israel.paa";
	};
	class Italy
	{
		name="Italie";
		flag="\Alysia_Client_Texture\Data\countries\Italy.paa";
	};
	class Jamaica
	{
		name="Jamaïque";
		flag="\Alysia_Client_Texture\Data\countries\Jamaica.paa";
	};
	class Japan
	{
		name="Japon";
		flag="\Alysia_Client_Texture\Data\countries\Japan.paa";
	};
	class Jordan
	{
		name="Jordanie";
		flag="\Alysia_Client_Texture\Data\countries\Jordan.paa";
	};
	class Kazkhstan
	{
		name="Kazakhstan";
		flag="\Alysia_Client_Texture\Data\countries\Kazkhstan.paa";
	};
	class Kenya
	{
		name="Kenya";
		flag="\Alysia_Client_Texture\Data\countries\Kenya.paa";
	};
	class Kyrgyzstan
	{
		name="Kirghizistan";
		flag="\Alysia_Client_Texture\Data\countries\Kyrgyzstan.paa";
	};
	class KiribatiRepublic
	{
		name="Kiribati";
		flag="\Alysia_Client_Texture\Data\countries\KiribatiRepublic.paa";
	};
	class Kuwait
	{
		name="Koweït";
		flag="\Alysia_Client_Texture\Data\countries\Kuwait.paa";
	};
	class Laos
	{
		name="Laos";
		flag="\Alysia_Client_Texture\Data\countries\Laos.paa";
	};
	class Lesotho
	{
		name="Lesotho";
		flag="\Alysia_Client_Texture\Data\countries\Lesotho.paa";
	};
	class Libanon
	{
		name="Liban";
		flag="\Alysia_Client_Texture\Data\countries\Libanon.paa";
	};
	class Liberia
	{
		name="Liberia";
		flag="\Alysia_Client_Texture\Data\countries\Liberia.paa";
	};
	class Lybia
	{
		name="Libye";
		flag="\Alysia_Client_Texture\Data\countries\Lybia.paa";
	};
	class Liechtenstein
	{
		name="Liechtenstein";
		flag="\Alysia_Client_Texture\Data\countries\Liechtenstein.paa";
	};
	class Lithuania
	{
		name="Lituanie";
		flag="\Alysia_Client_Texture\Data\countries\Lithuania.paa";
	};
	class Luxembourg
	{
		name="Luxembourg";
		flag="\Alysia_Client_Texture\Data\countries\Luxembourg.paa";
	};
	class Madagascar
	{
		name="Madagascar";
		flag="\Alysia_Client_Texture\Data\countries\Madagascar.paa";
	};
	class Malaysia
	{
		name="Malaisie";
		flag="\Alysia_Client_Texture\Data\countries\Malaysia.paa";
	};
	class Malawi
	{
		name="Malawi";
		flag="\Alysia_Client_Texture\Data\countries\Malawi.paa";
	};
	class Maldives
	{
		name="Maldives";
		flag="\Alysia_Client_Texture\Data\countries\Maldives.paa";
	};
	class Mali
	{
		name="Mali";
		flag="\Alysia_Client_Texture\Data\countries\Mali.paa";
	};
	class MaltaRepublic
	{
		name="Malte";
		flag="\Alysia_Client_Texture\Data\countries\MaltaRepublic.paa";
	};
	class Morocco
	{
		name="Maroc";
		flag="\Alysia_Client_Texture\Data\countries\Morocco.paa";
	};
	class Mauritius
	{
		name="Maurice";
		flag="\Alysia_Client_Texture\Data\countries\Mauritius.paa";
	};
	class Mauritania
	{
		name="Mauritanie";
		flag="\Alysia_Client_Texture\Data\countries\Mauritania.paa";
	};
	class Comorros
	{
		name="Comorres";
		flag="\Alysia_Client_Texture\Data\countries\Comorros.paa";
	};
	class Mexico
	{
		name="Mexique";
		flag="\Alysia_Client_Texture\Data\countries\Mexico.paa";
	};
	class Moldova
	{
		name="Moldavie";
		flag="\Alysia_Client_Texture\Data\countries\Moldova.paa";
	};
	class Monaco
	{
		name="Monaco";
		flag="\Alysia_Client_Texture\Data\countries\Monaco.paa";
	};
	class Mongolia
	{
		name="Mongolie";
		flag="\Alysia_Client_Texture\Data\countries\Mongolia.paa";
	};
	class Montenegro
	{
		name="Monténégro";
		flag="\Alysia_Client_Texture\Data\countries\Montenegro.paa";
	};
	class Mozambique
	{
		name="Mozambique";
		flag="\Alysia_Client_Texture\Data\countries\Mozambique.paa";
	};
	class Nambia
	{
		name="Namibie";
		flag="\Alysia_Client_Texture\Data\countries\Nambia.paa";
	};
	class NauruRepublic
	{
		name="Nauru";
		flag="\Alysia_Client_Texture\Data\countries\NauruRepublic.paa";
	};
	class Nepal
	{
		name="Népal";
		flag="\Alysia_Client_Texture\Data\countries\Nepal.paa";
	};
	class Nicaragua
	{
		name="Nicaragua";
		flag="\Alysia_Client_Texture\Data\countries\Nicaragua.paa";
	};
	class Niger
	{
		name="Niger";
		flag="\Alysia_Client_Texture\Data\countries\Niger.paa";
	};
	class Nigeria
	{
		name="Nigeria";
		flag="\Alysia_Client_Texture\Data\countries\Nigeria.paa";
	};
	class Norway
	{
		name="Norvège";
		flag="\Alysia_Client_Texture\Data\countries\Norway.paa";
	};
	class NewZealand
	{
		name="Nouvelle-Zélande";
		flag="\Alysia_Client_Texture\Data\countries\NewZealand.paa";
	};
	class Oman
	{
		name="Oman";
		flag="\Alysia_Client_Texture\Data\countries\Oman.paa";
	};
	class Pakistan
	{
		name="Pakistan";
		flag="\Alysia_Client_Texture\Data\countries\Pakistan.paa";
	};
	class Panama
	{
		name="Panama";
		flag="\Alysia_Client_Texture\Data\countries\Panama.paa";
	};
	class Paraguay
	{
		name="Paraguay";
		flag="\Alysia_Client_Texture\Data\countries\Paraguay.paa";
	};
	class Netherlands
	{
		name="Pays-Bas";
		flag="\Alysia_Client_Texture\Data\countries\Netherlands.paa";
	};
	class Peru
	{
		name="Pérou";
		flag="\Alysia_Client_Texture\Data\countries\Peru.paa";
	};
	class Philippines
	{
		name="Philippines";
		flag="\Alysia_Client_Texture\Data\countries\Philippines.paa";
	};
	class Poland
	{
		name="Pologne";
		flag="\Alysia_Client_Texture\Data\countries\Poland.paa";
	};
	class Portugal
	{
		name="Portugal";
		flag="\Alysia_Client_Texture\Data\countries\Portugal.paa";
	};
	class Qatar
	{
		name="Qatar";
		flag="\Alysia_Client_Texture\Data\countries\Qatar.paa";
	};
	class CzechRepublic
	{
		name="République tchèque";
		flag="\Alysia_Client_Texture\Data\countries\CzechRepublic.paa";
	};
	class Roumania
	{
		name="Roumanie";
		flag="\Alysia_Client_Texture\Data\countries\Roumania.paa";
	};
	class UnitedKingdom
	{
		name="Royaume-Uni";
		flag="\Alysia_Client_Texture\Data\countries\UnitedKingdom.paa";
	};
	class Russia
	{
		name="Russie";
		flag="\Alysia_Client_Texture\Data\countries\Russia.paa";
	};
	class Rwanda
	{
		name="Rwanda";
		flag="\Alysia_Client_Texture\Data\countries\Rwanda.paa";
	};
	class SaintLucia
	{
		name="Sainte-Lucie";
		flag="\Alysia_Client_Texture\Data\countries\SaintLucia.paa";
	};
	class SaintVincentGrenadines
	{
		name="Saint-Vincent-et-les-Grenadines";
		flag="\Alysia_Client_Texture\Data\countries\SaintVincentGrenadines.paa";
	};
	class Samoa
	{
		name="Samoa";
		flag="\Alysia_Client_Texture\Data\countries\Samoa.paa";
	};
	class Senegal
	{
		name="Sénégal";
		flag="\Alysia_Client_Texture\Data\countries\Senegal.paa";
	};
	class SerbiaRepuplic
	{
		name="Serbie";
		flag="\Alysia_Client_Texture\Data\countries\SerbiaRepuplic.paa";
	};
	class Seychelles
	{
		name="Seychelles";
		flag="\Alysia_Client_Texture\Data\countries\Seychelles.paa";
	};
	class SierraLeone
	{
		name="Sierra Leone";
		flag="\Alysia_Client_Texture\Data\countries\SierraLeone.paa";
	};
	class Singapore
	{
		name="Singapour";
		flag="\Alysia_Client_Texture\Data\countries\Singapore.paa";
	};
	class Slovakia
	{
		name="Slovaquie";
		flag="\Alysia_Client_Texture\Data\countries\Slovakia.paa";
	};
	class Slovenia
	{
		name="Slovénie";
		flag="\Alysia_Client_Texture\Data\countries\Slovenia.paa";
	};
	class Somalia
	{
		name="Somalie";
		flag="\Alysia_Client_Texture\Data\countries\Somalia.paa";
	};
	class SriLanka
	{
		name="Sri Lanka";
		flag="\Alysia_Client_Texture\Data\countries\SriLanka.paa";
	};
	class Sweden
	{
		name="Suède";
		flag="\Alysia_Client_Texture\Data\countries\Sweden.paa";
	};
	class Switzerland
	{
		name="Suisse";
		flag="\Alysia_Client_Texture\Data\countries\Switzerland.paa";
	};
	class Suriname
	{
		name="Suriname";
		flag="\Alysia_Client_Texture\Data\countries\Suriname.paa";
	};
	class Syria
	{
		name="Syrie";
		flag="\Alysia_Client_Texture\Data\countries\Syria.paa";
	};
	class Tadjikistan
	{
		name="Tadjikistan";
		flag="\Alysia_Client_Texture\Data\countries\Tadjikistan.paa";
	};
	class Taiwan
	{
		name="Taïwan";
		flag="\Alysia_Client_Texture\Data\countries\Taiwan.paa";
	};
	class Tanzania
	{
		name="Tanzanie";
		flag="\Alysia_Client_Texture\Data\countries\Tanzania.paa";
	};
	class Thailand
	{
		name="Thaïlande";
		flag="\Alysia_Client_Texture\Data\countries\Thailand.paa";
	};
	class Togo
	{
		name="Togo";
		flag="\Alysia_Client_Texture\Data\countries\Togo.paa";
	};
	class Tonga
	{
		name="Tonga";
		flag="\Alysia_Client_Texture\Data\countries\Tonga.paa";
	};
	class Tunisia
	{
		name="Tunisie";
		flag="\Alysia_Client_Texture\Data\countries\Tunisia.paa";
	};
	class Turkmenistan
	{
		name="Turkménistan";
		flag="\Alysia_Client_Texture\Data\countries\Turkmenistan.paa";
	};
	class Turkey
	{
		name="Turquie";
		flag="\Alysia_Client_Texture\Data\countries\Turkey.paa";
	};
	class Tuvalu
	{
		name="Tuvalu";
		flag="\Alysia_Client_Texture\Data\countries\Tuvalu.paa";
	};
	class Ukraine
	{
		name="Ukraine";
		flag="\Alysia_Client_Texture\Data\countries\Ukraine.paa";
	};
	class Uruguay
	{
		name="Uruguay";
		flag="\Alysia_Client_Texture\Data\countries\Uruguay.paa";
	};
	class Vanatu
	{
		name="Vanuatu";
		flag="\Alysia_Client_Texture\Data\countries\Vanatu.paa";
	};
	class Venezuela
	{
		name="Venezuela";
		flag="\Alysia_Client_Texture\Data\countries\Venezuela.paa";
	};
	class Vietnam
	{
		name="Viêt Nam";
		flag="\Alysia_Client_Texture\Data\countries\Vietnam.paa";
	};
	class Yemen
	{
		name="Yémen";
		flag="\Alysia_Client_Texture\Data\countries\Yemen.paa";
	};
	class Zambia
	{
		name="Zambie";
		flag="\Alysia_Client_Texture\Data\countries\Zambia.paa";
	};
	class Zimbabwe
	{
		name="Zimbabwe";
		flag="\Alysia_Client_Texture\Data\countries\Zimbabwe.paa";
	};
};
