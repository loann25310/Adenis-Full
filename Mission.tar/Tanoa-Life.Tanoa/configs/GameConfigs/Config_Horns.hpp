class ADENIS_HORN
{
	class east
	{
		item="horn_east";
		sound="sirene_east";
		sleep=4;
	};
	class guer
	{
		item="horn_guer";
		sound="sirene_guer";
		sleep=2;
	};
	class west
	{
		item="horn_west";
		sound="sirene_west";
		sleep=0.7;
	};
};
