class ADENIS_ANIMATIONS
{
	class HG_Crazy_Dance
	{
		name="Dance folle";
	};

	class HG_crazydrunkdance
	{
		name="Dance alcolisé";
	};

	class HG_Dance
	{
		name="Dance de soirée";
	};

	class HG_robotdance
	{
		name="Dance Robot";
	};

	class HG_dubstepdance
	{
		name="Dance Robot 2";
	};

	class HG_dubstepPop
	{
		name="Dance Robot 3";
	};

	class HG_DuoIvan
	{
		name="Dance en duo";
	};

	class HG_hiphopdance
	{
		name="Dance Hip-hop";
	};

	class HG_nightclubdance
	{
		name="Dance de Night Club";
	};

	class HG_russiandance
	{
		name="Dance Russe";
	};

	class HubWoundedProne_idle1
	{
		name="Coucher sur le dos";
	};

	class InBaseMoves_HandsBehindBack1
	{
		name="Mains dans le dos";
	};

	class Acts_A_M01_briefing
	{
		name="Mains à la taille";
	};

	class actionAnimPushup
	{
		name="Pompe";
	};

	class actionAnimKata
	{
		name="Kata";
	};

	class actionAnimKneeBend
	{
		name="Flexion";
	};

	class actionAnimSplit
	{
		name="Grand écart";
	};

	class actionAnimSitTired
	{
		name="Assis";
	};

	class actionAnimPissing
	{
		name="Uriner";
	};
};