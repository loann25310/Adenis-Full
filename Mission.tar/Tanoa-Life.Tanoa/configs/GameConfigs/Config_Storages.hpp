class ADENIS_STORAGES
{
	class Diablo_Coffre_Small
	{
		inventory=600;
		// maximumLoad=2000;
	};
	class Diablo_Coffre_Medium
	{
		inventory=1500;
		// maximumLoad=3500;
	};
	class Diablo_Coffre_Large
	{
		inventory=4000;
		// maximumLoad=5000;
	};
	class Diablo_Coffre_Extra
	{
		inventory=7000;
		// maximumLoad=10000;
	};
	class Diablo_Coffre_Mega
	{
		inventory=20000;
		// maximumLoad=25000;
	};
	class Diablo_Coffre_Hangar
	{
		inventory=5500;
		// maximumLoad=25000;
	};
	class Diablo_Coffre_Entreprise
	{
		inventory=6500;
		// maximumLoad=25000;
	};
	class Diablo_Coffre_Extra_Large
	{
		inventory=5500;
		// maximumLoad=25000;
	};
};
