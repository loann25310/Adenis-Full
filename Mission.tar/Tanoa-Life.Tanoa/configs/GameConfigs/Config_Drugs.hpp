class ADENIS_DRUGS
{
	class marijuana
	{

	};
	class methp
	{

	};
	class heroinps
	{

	};
	class cocainepc
	{

	};
	class cocainep
	{

	};
	class mushroom_dry
	{

	};
};
