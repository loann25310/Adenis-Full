class RscDisplayDefault
{
	movingEnable=0;
	enableSimulation=1;
};
